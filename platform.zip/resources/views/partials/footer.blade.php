<div class="icono-whatsapp w-14 fixed bottom-8 right-8 z-50">
  <img src="/images/icono-whatsapp.png" alt="">
</div>
<footer class="footer lg:px-28 mx-auto flex flex-col lg:flex-row justify-between items-center py-3">
  <div class="copyright">Copyright 2022 - sanchezplayland.com</div>
  <div class="attribution">Diseño por <a href="https://www.followermg.com">Follower Media Group</a></div>
</footer>