@extends('layouts.interior')
@section('title', 'Lista de brincolines')

@section('content')
@livewire('show-inflables')
@endsection